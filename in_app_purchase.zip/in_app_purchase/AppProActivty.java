package com.drivemeto.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.drivemeto.R;
import com.drivemeto.Tagview.Constants;
import com.drivemeto.baseclasses.AppApplication;
import com.drivemeto.baseclasses.MVPActivity;
import com.drivemeto.inapppurchase.BillingProcessor;
import com.drivemeto.inapppurchase.TransactionDetails;
import com.drivemeto.models.Authentication.Login;
import com.drivemeto.models.Response;
import com.drivemeto.presenter.AppProPresenter;
import com.drivemeto.utils.ApiParamEnum;
import com.drivemeto.utils.ApiRequestUrlEnum;
import com.drivemeto.utils.AppUtils;
import com.drivemeto.utils.PreferenceUtils;
import com.drivemeto.validators.ValidationErrorModel;
import com.drivemeto.views.AppProView;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by imobdev on 2/10/17.
 */

public class AppProActivty extends MVPActivity<AppProPresenter, AppProView<Response>>
        implements AppProView<Response>, BillingProcessor.IBillingHandler {


    private static final String TAG = "APPPROACTIVITY";
    @BindView(R.id.ivTextLogo)
    ImageView ivTextLogo;
    @BindView(R.id.title1)
    TextView title1;
    @BindView(R.id.tvBuy)
    TextView tvBuy;
    @BindView(R.id.tvShareApp)
    TextView tvShareApp;
    @BindView(R.id.ivCloseIcon)
    ImageView ivCloseIcon;
    @BindView(R.id.tvMessage2)
    TextView tvMessage2;
    @BindView(R.id.tvMessage1)
    TextView tvMessage1;

    private BillingProcessor billingProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pro);
        ButterKnife.bind(this);

        tvBuy.setAllCaps(false);
        tvBuy.setText(getSpannedText(getString(R.string.buy_drivemetopro)));

        setViewProperty();
        setUpInAppPurchase();
    }

    @Override
    public void onDestroy() {
        if (billingProcessor != null) {
            billingProcessor.release();
        }
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e(TAG, "onActivityResult: ");
        if (!billingProcessor.handleActivityResult(requestCode, resultCode, data))
            super.onActivityResult(requestCode, resultCode, data);

    }

    private void setUpInAppPurchase() {
        billingProcessor = new BillingProcessor(this, Constants.RELEASE_LICENSE_KEY, this);
    }

    private void purchase() {
        if (isValidateForConsume(PreferenceUtils.getInstance(this).getLoginData().getUserData().getmUserEmail())) {
            billingProcessor.purchase(this, Constants.RELEASE_PRODUCT_ID,
                    PreferenceUtils.getInstance(this).getLoginData().getUserData().getmUserEmail());
        } else {
            Toast.makeText(this, R.string.error_payment_account_already_use, Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private boolean isValidateForConsume(String emailId) {
        ArrayList<String> purchasedLists = billingProcessor.purchasedHistory();
        if (emailId != null) {
            if (purchasedLists != null && purchasedLists.size() > 0) {
                for (String data : purchasedLists) {
                    try {
                        JSONObject jsonObject = new JSONObject(data);
                        if (/*!jsonObject.optString("productId").equalsIgnoreCase("ppmconsumable") || */jsonObject.optString("developerPayload").contains(emailId) || jsonObject.optString("developerPayload").equalsIgnoreCase(""))
                            return true;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                return true;
            }
        }
        return false;
    }


    private Spanned getSpannedText(String text) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(text, Html.FROM_HTML_MODE_COMPACT);
        } else {
            return Html.fromHtml(text);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
//        AppApplication.getInstance().trackScreenView(getResources().getString(R.string.pro_screen));
        AppApplication.getInstance().sendFireBaseAnalytics(getResources().getString(R.string.pro_screen));
    }

    private void setViewProperty() {

        String terms_conditions = getResources().getString(R.string.title5) + " " + getResources().getString(R.string.title6);
        // tvMessage2.setMovementMethod(LinkMovementMethod.getInstance());
        //tvMessage2.setText(addClickablePart(terms_conditions), TextView.BufferType.SPANNABLE);

        Spannable spannablemsg2 = new SpannableString(terms_conditions);
        spannablemsg2.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), terms_conditions.indexOf(getResources().getString(R.string.title6))
                , terms_conditions.indexOf(getResources().getString(R.string.title6)) + getResources().getString(R.string.title6).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        /*spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(RegistrationActivity.this, R.color.color_blue)), 12, 30, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(RegistrationActivity.this, R.color.color_blue)), 35, 50, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);*/
        tvMessage2.setText(spannablemsg2);


        String msg1 = getResources().getString(R.string.title3) + " " + getResources().getString(R.string.title4);
        // tvMessage2.setMovementMethod(LinkMovementMethod.getInstance());
        //tvMessage2.setText(addClickablePart(terms_conditions), TextView.BufferType.SPANNABLE);

        Spannable spannablemsg1 = new SpannableString(msg1);
        spannablemsg1.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), msg1.indexOf(getResources().getString(R.string.title4))
                , msg1.indexOf(getResources().getString(R.string.title4)) + getResources().getString(R.string.title4).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        /*spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(RegistrationActivity.this, R.color.color_blue)), 12, 30, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(RegistrationActivity.this, R.color.color_blue)), 35, 50, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);*/
        tvMessage1.setText(spannablemsg1);

    }

    private Spannable addClickablePart(String str) {
        Spannable ssb = new SpannableStringBuilder(str);
        ssb.setSpan(new ClickableSpan() {

                        @Override
                        public void onClick(View widget) {

                        }

                        @Override
                        public void updateDrawState(TextPaint ds) {
                            super.updateDrawState(ds);
                            ds.setUnderlineText(false);

                        }

                    }, str.indexOf(getResources().getString(R.string.term2))
                , str.indexOf(getResources().getString(R.string.term2)) + getResources().getString(R.string.term2).length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);

        ssb.setSpan(new ClickableSpan() {

                        @Override
                        public void onClick(View widget) {

                        }

                        @Override
                        public void updateDrawState(TextPaint ds) {
                            super.updateDrawState(ds);
                            ds.setUnderlineText(false);
                        }

                    }, str.indexOf(getResources().getString(R.string.term4))
                , str.indexOf(getResources().getString(R.string.term4)) + getResources().getString(R.string.term4).length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
        return ssb;
    }


    @NonNull
    @Override
    public AppProPresenter createPresenter() {
        return new AppProPresenter();
    }

    @NonNull
    @Override
    public AppProView<Response> attachView() {
        return this;
    }


    @OnClick({R.id.tvBuy, R.id.tvShareApp, R.id.ivCloseIcon})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tvBuy:
                purchase();
                break;
            case R.id.tvShareApp:

                AppUtils.shareData(AppProActivty.this,
                        getString(R.string.app_name) +
                                "\n\n" +
                                getString(R.string.share_link));
                break;
            case R.id.ivCloseIcon:
                finish();
                break;
        }
    }

    private void callUpdateApi() {
        Login login = PreferenceUtils.getInstance(this).getLoginData();
        String url = ApiRequestUrlEnum.UPDATE_PURCHASE_PLAN.getValue();
        HashMap<String, String> params = new HashMap<>();

        params.put(ApiParamEnum.DEVICETYPE.getValue(), AppUtils.device_type);
        params.put(ApiParamEnum.ACCESSTOKEN.getValue(), login.getAccess_token());
        params.put(ApiParamEnum.USERID.getValue(), login.getUserData().getmUserId());
        params.put(ApiParamEnum.PLAN_PURCHASE.getValue(), "1");
        params.put(ApiParamEnum.PRODUCT_ID.getValue(),
                PreferenceUtils.getInstance(this).getProductId());
        params.put(ApiParamEnum.ORDER_ID.getValue(),
                PreferenceUtils.getInstance(this).getOrderId());
        params.put(ApiParamEnum.PURCHASE_TOKEN.getValue(),
                PreferenceUtils.getInstance(this).getPurchaseToken());


        getPresenter().callUpdateProfileApi(params, url);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
    }

    @Override
    public void onSuccess(Response response) {
        Login login = PreferenceUtils.getInstance(this).getLoginData();
        login.getUserData().setProApp(1);
        PreferenceUtils.getInstance(this).setLoginData(login);
        PreferenceUtils.getInstance(this).setPaymentDone(false);
        EventBus.getDefault().post(login);
        finish();
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
        finish();
    }

    @Override
    public void onProductPurchased(String productId, TransactionDetails details) {
        Log.e(TAG, "onProductPurchased: ");
        PreferenceUtils.getInstance(this).setPaymentDone(true);
        PreferenceUtils.getInstance(this).setProductId(details.productId);
        PreferenceUtils.getInstance(this).setOrderId(details.orderId);
        PreferenceUtils.getInstance(this).setPurchaseToken(details.purchaseToken);

        callUpdateApi();
    }

    @Override
    public void onPurchaseHistoryRestored() {
        Log.e(TAG, "onPurchaseHistoryRestored: ");
    }

    @Override
    public void onBillingError(int errorCode, Throwable error) {
        Log.e(TAG, "onBillingError: ");
    }

    @Override
    public void onBillingInitialized() {
        Log.e(TAG, "onBillingInitialized: ");
    }
}
